# Defaults for pebble-remote initscript
# sourced by /etc/init.d/pebble-remote
# installed at /etc/default/pebble-remote by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
