?package(pebble-remote):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="pebble-remote" command="/usr/bin/pebble-remote"
